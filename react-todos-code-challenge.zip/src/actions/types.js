export const TOGGLE_TODO = "TOGGLE_TODO";
export const ADD_TODO = "ADD_TODO";
export const DELETE_TODO = "DELETE_TODO";
export const SET_COMPLETED_TODO = "SET_COMPLETED_TODO";
export const EDIT_TEXT_TODO = "EDIT_TEXT_TODO";
